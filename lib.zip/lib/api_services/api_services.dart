import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'https://prakrutitech.xyz/payal';

  // Signup User
  static Future<Map<String, dynamic>> signupUser({
    required String name,
    required String email,
    required String password,
  }) async {
    final url = Uri.parse('$baseUrl/add_user.php');
    final response = await http.post(url, body: {
      'name': name,
      'email': email,
      'password': password,
    });

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to signup');
    }
  }

  // Login User
  static Future<Map<String, dynamic>> loginUser({
    required String email,
    required String password,
  }) async {
    final url = Uri.parse('$baseUrl/login_user.php');
    final response = await http.post(url, body: {
      'email': email,
      'password': password,
    });

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to login');
    }
  }

  // Add Category
  static Future<Map<String, dynamic>> addCategory({
    required String userId,
    required String name,
    required String type,
  }) async {
    final url = Uri.parse('$baseUrl/add_category.php');
    final response = await http.post(url, body: {
      'user_id': userId,
      'name': name,
      'type': type,
    });

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to add category');
    }
  }

  // Add Transaction
  static Future<Map<String, dynamic>> addTransaction({
    required String userId,
    required String categoryId,
    required String amount,
    required String date,
    required String note,
  }) async {
    final url = Uri.parse('$baseUrl/add_transaction.php');
    final response = await http.post(url, body: {
      'user_id': userId,
      'category_id': categoryId,
      'amount': amount,
      'date': date,
      'note': note,
    });

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to add transaction');
    }
  }

  // View Categories
  static Future<Map<String, dynamic>> viewCategories(String userId) async {
    final url = Uri.parse('$baseUrl/view_category.php?user_id=$userId');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to fetch categories');
    }
  }

  // View Transactions
  static Future<Map<String, dynamic>> viewTransactions(String userId) async {
    final url = Uri.parse('$baseUrl/view_transactions.php?user_id=$userId');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to fetch transactions');
    }
  }

  // Get Reports
  static Future<Map<String, dynamic>> getReports(String userId) async {
    final url = Uri.parse('$baseUrl/reports.php');
    final response = await http.post(url, body: {
      'user_id': userId,
    });

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to fetch reports');
    }
  }

  // Get Overview
  static Future<Map<String, dynamic>> getOverview(String userId) async {
    final url = Uri.parse('$baseUrl/overview.php');
    final response = await http.post(url, body: {
      'user_id': userId,
    });

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to fetch overview');
    }
  }

  // Update Category
  static Future<Map<String, dynamic>> updateCategory({
    required String id,
    required String name,
    required String type,
  }) async {
    final url = Uri.parse('$baseUrl/update.php');
    final response = await http.post(url, body: {
      'action': 'update_category',
      'id': id,
      'name': name,
      'type': type,
    });

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to update category');
    }
  }

  // Delete Category
  static Future<Map<String, dynamic>> deleteCategory(String id) async {
    final url = Uri.parse('$baseUrl/delete_category.php?id=$id');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to delete category');
    }
  }

  // Delete Transaction
  static Future<Map<String, dynamic>> deleteTransaction(String transactionId) async {
    final url = Uri.parse('$baseUrl/delete_transaction.php');
    final response = await http.post(url, body: {
      'transaction_id': transactionId,
    });

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to delete transaction');
    }
  }

  // View User
  static Future<Map<String, dynamic>> viewUser(String userId) async {
    final url = Uri.parse('$baseUrl/view_user.php?user_id=$userId');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to fetch user');
    }
  }

  // Update User
  static Future<Map<String, dynamic>> updateUser({
    required String id,
    required String name,
    required String email,
  }) async {
    final url = Uri.parse('$baseUrl/update.php');
    final response = await http.post(url, body: {
      'action': 'update_user',
      'id': id,
      'name': name,
      'email': email,
    });

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to update user');
    }
  }
}