import 'package:flutter/material.dart';
import '../api_services/api_services.dart';
import '../screens/auth/login.dart';
import '../screens/edit_profile.dart';
import '../screens/help.dart';
import '../screens/security.dart';
import '../screens/setting.dart';
import '../shared_preference/shared_pref.dart';

class ProfileTab extends StatefulWidget {
  final String userId;
  const ProfileTab({super.key, required this.userId});

  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  bool isLoading = true;
  Map<String, dynamic>? userData;

  @override
  void initState() {
    super.initState();
    fetchUser();
  }
  Future<void> fetchUser() async {
    setState(() => isLoading = true);
    try {
      print("🔍 Fetching user data for ID: ${widget.userId}");
      final response = await ApiService.viewUser(widget.userId);
      print("📱 User API Response: $response");

      if (response['code'] == 200 &&
          response['users'] != null &&
          response['users'].isNotEmpty) {

        // FIX: Find the correct user from the list
        final usersList = response['users'];
        final currentUser = usersList.firstWhere(
              (user) => user['id'].toString() == widget.userId,
          orElse: () => usersList.isNotEmpty ? usersList[0] : null,
        );

        if (currentUser != null) {
          print("✅ User data found: $currentUser");
          setState(() => userData = currentUser);

          // Debug info
          if (currentUser['id'].toString() != widget.userId) {
            print("⚠️  Showing different user than logged in (API issue)");
          }
        } else {
          print("❌ No user data available");
          setState(() => userData = null);
        }
      } else {
        print("❌ No user data found in API response");
        setState(() => userData = null);
      }
    } catch (e) {
      print("❌ Error fetching user: $e");
      setState(() => userData = null);
    }
    setState(() => isLoading = false);
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _logout() async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await Pref.logout();
              if (!mounted) return;
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginScreen()),
                    (route) => false,
              );
            },
            child: const Text('Logout', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pinkAccent,
      body: Column(
        children: [
          // Header Section
          Container(
            padding: const EdgeInsets.only(top: 60, bottom: 30),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SizedBox(
                height: 40,
                child: Stack(
                  alignment: Alignment.center,
                  children: const [
                    Center(
                      child: Text(
                        "Profile",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Positioned(
                      right: 0,
                      child: Icon(Icons.notifications_none, color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Content Section
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 30),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(40)),
              ),
              child: isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : SingleChildScrollView(
                child: Column(
                  children: [
                    // Profile Avatar and Info
                    _buildProfileHeader(),
                    const SizedBox(height: 30),

                    // Profile Options
                    _buildProfileOptions(),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileHeader() {
    return Column(
      children: [
        const CircleAvatar(
          radius: 45,
          backgroundColor: Colors.grey,
          child: Icon(Icons.person, size: 50, color: Colors.white),
        ),
        const SizedBox(height: 10),
        Text(
          userData?['name'] ?? 'User',
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 4),
        Text(
          userData?['email'] ?? 'No Email',
          style: const TextStyle(
            fontSize: 14,
            color: Colors.grey,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 4),
        Text(
          "ID: ${userData?['id'] ?? widget.userId}",
          style: const TextStyle(
            fontSize: 12,
            color: Colors.grey,
          ),
        ),
        // Debug info - remove this in production
        if (userData?['name'] == 'User') ...[
          const SizedBox(height: 8),
          Text(
            "Debug: Using fallback data",
            style: TextStyle(
              fontSize: 10,
              color: Colors.orange[700],
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildProfileOptions() {
    return Column(
      children: [
        _buildProfileOption(
          Icons.person_outline,
          'Edit Profile',
          Colors.blue,
              () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => EditProfile(
                  userId: widget.userId,
                  currentName: userData?['name'] ?? '',
                  currentEmail: userData?['email'] ?? '',
                ),
              ),
            ).then((_) => fetchUser());
          },
        ),
        _buildProfileOption(
          Icons.security_outlined,
          'Security',
          Colors.green,
              () {
            Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const Security())
            );
          },
        ),
        _buildProfileOption(
          Icons.settings_outlined,
          'Settings',
          Colors.orange,
              () {
            Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const Settings())
            );
          },
        ),
        _buildProfileOption(
          Icons.help_outline,
          'Help & Support',
          Colors.purple,
              () {
            Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const Help())
            );
          },
        ),
        const SizedBox(height: 10),
        _buildProfileOption(
          Icons.logout,
          'Logout',
          Colors.red,
          _logout,
        ),
      ],
    );
  }

  Widget _buildProfileOption(IconData icon, String title, Color color, VoidCallback onTap) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: Container(
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          padding: const EdgeInsets.all(10),
          child: Icon(icon, color: color, size: 22),
        ),
        title: Text(
          title,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: Colors.black87,
          ),
        ),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      ),
    );
  }
}