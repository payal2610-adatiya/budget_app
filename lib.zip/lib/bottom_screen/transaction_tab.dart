import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../api_services/api_services.dart';
import '../app_colors/app_colors.dart';

class TransactionsTab extends StatefulWidget {
  final String userId;
  const TransactionsTab({super.key, required this.userId});

  @override
  State<TransactionsTab> createState() => _TransactionsTabState();
}

class _TransactionsTabState extends State<TransactionsTab> {
  List<dynamic> transactions = [];
  Map<String, dynamic>? reportsData;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => isLoading = true);
    try {
      final [reports, transactionsData] = await Future.wait([
        ApiService.getReports(widget.userId),
        ApiService.viewTransactions(widget.userId),
      ]);

      setState(() {
        reportsData = reports;
        transactions = transactionsData['transactions'] ?? [];
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
      _showSnackBar('Error: $e');
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _deleteTransaction(String transactionId) async {
    try {
      final result = await ApiService.deleteTransaction(transactionId);
      if (result['code'] == 200) {
        _showSnackBar('Transaction deleted');
        _loadData();
      }
    } catch (e) {
      _showSnackBar('Error deleting transaction: $e');
    }
  }

  void _showAddTransactionDialog() {
    showDialog(
      context: context,
      builder: (context) => AddTransactionDialog(
        userId: widget.userId,
        onTransactionAdded: _loadData,
      ),
    );
  }

  double get totalBalance {
    if (reportsData == null) return 0;
    final income = double.tryParse(reportsData!['income']?.toString() ?? '0') ?? 0;
    final expense = double.tryParse(reportsData!['expense']?.toString() ?? '0') ?? 0;
    return income - expense;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddTransactionDialog,
        backgroundColor: AppColors.bottomNavSelected,
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFa8edea), Color(0xFFfed6e3)],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  const Text(
                    "Total Balance",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "\$${totalBalance.toStringAsFixed(2)}",
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildSummaryItem("Income", reportsData?['income'] ?? 0, Colors.green),
                      _buildSummaryItem("Expense", reportsData?['expense'] ?? 0, Colors.red),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Transactions List
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : transactions.isEmpty
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.receipt_long, size: 60, color: Colors.grey[400]),
                  const SizedBox(height: 16),
                  const Text("No transactions found"),
                  const SizedBox(height: 8),
                  ElevatedButton(
                    onPressed: _showAddTransactionDialog,
                    child: const Text("Add Your First Transaction"),
                  ),
                ],
              ),
            )
                : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: transactions.length,
              itemBuilder: (context, index) {
                final transaction = transactions[index];
                final amount = double.tryParse(transaction['amount']?.toString() ?? '0') ?? 0;
                final isIncome = transaction['category_type'] == 'income';

                return Dismissible(
                  key: Key(transaction['id'].toString()),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    color: Colors.red,
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20),
                    child: const Icon(Icons.delete, color: Colors.white),
                  ),
                  onDismissed: (direction) => _deleteTransaction(transaction['id'].toString()),
                  child: Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: isIncome
                            ? Colors.green.withOpacity(0.2)
                            : Colors.red.withOpacity(0.2),
                        child: Icon(
                          isIncome ? Icons.arrow_downward : Icons.arrow_upward,
                          color: isIncome ? Colors.green : Colors.red,
                        ),
                      ),
                      title: Text(transaction['note'] ?? 'No description'),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(transaction['category_name'] ?? 'Uncategorized'),
                          Text(DateFormat('MMM dd, yyyy').format(
                              DateTime.parse(transaction['date'] ?? DateTime.now().toString())
                          )),
                        ],
                      ),
                      trailing: Text(
                        "${isIncome ? '+' : '-'} \$${amount.abs().toStringAsFixed(2)}",
                        style: TextStyle(
                          color: isIncome ? Colors.green : Colors.red,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryItem(String title, dynamic value, Color color) {
    final amount = double.tryParse(value?.toString() ?? '0') ?? 0;
    return Column(
      children: [
        Text(
          title,
          style: const TextStyle(color: Colors.white70, fontSize: 14),
        ),
        const SizedBox(height: 4),
        Text(
          "\$${amount.toStringAsFixed(2)}",
          style: TextStyle(
            color: color,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}

// FIXED Add Transaction Dialog
class AddTransactionDialog extends StatefulWidget {
  final String userId;
  final VoidCallback onTransactionAdded;

  const AddTransactionDialog({
    super.key,
    required this.userId,
    required this.onTransactionAdded,
  });

  @override
  State<AddTransactionDialog> createState() => _AddTransactionDialogState();
}

class _AddTransactionDialogState extends State<AddTransactionDialog> {
  final TextEditingController amountController = TextEditingController();
  final TextEditingController noteController = TextEditingController();
  DateTime selectedDate = DateTime.now();
  String? selectedCategoryId;
  List<dynamic> categories = [];
  bool isLoading = false;
  bool categoriesLoading = true;

  @override
  void initState() {
    super.initState();
    _loadCategories();
  }

  Future<void> _loadCategories() async {
    try {
      print("Loading categories for user: ${widget.userId}");
      final response = await ApiService.viewCategories(widget.userId);
      print("Categories API response: $response");

      if (mounted) {
        setState(() {
          categories = response['categories'] ?? [];
          categoriesLoading = false;
        });
        print("Loaded ${categories.length} categories");
      }
    } catch (e) {
      print("Error loading categories: $e");
      if (mounted) {
        setState(() {
          categoriesLoading = false;
        });
      }
      _showSnackBar('Error loading categories: $e');
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null && picked != selectedDate && mounted) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  Future<void> _addTransaction() async {
    if (selectedCategoryId == null) {
      _showSnackBar('Please select a category');
      return;
    }

    if (amountController.text.isEmpty) {
      _showSnackBar('Please enter amount');
      return;
    }

    final amount = double.tryParse(amountController.text);
    if (amount == null || amount <= 0) {
      _showSnackBar('Please enter a valid amount');
      return;
    }

    setState(() => isLoading = true);
    try {
      print("Adding transaction with category: $selectedCategoryId, amount: ${amountController.text}");

      final result = await ApiService.addTransaction(
        userId: widget.userId,
        categoryId: selectedCategoryId!,
        amount: amountController.text,
        date: DateFormat('yyyy-MM-dd').format(selectedDate),
        note: noteController.text.isEmpty ? 'Transaction' : noteController.text,
      );

      print("Add transaction response: $result");

      if (result['code'] == 200) {
        _showSnackBar('Transaction added successfully');
        widget.onTransactionAdded();
        if (mounted) {
          Navigator.pop(context);
        }
      } else {
        _showSnackBar(result['message'] ?? 'Failed to add transaction');
      }
    } catch (e) {
      print("Error adding transaction: $e");
      _showSnackBar('Error: $e');
    }
    if (mounted) {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.8,
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  "Add Transaction",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),

                // Amount
                TextFormField(
                  controller: amountController,
                  keyboardType: TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                    labelText: "Amount*",
                    prefixText: "\$",
                    border: OutlineInputBorder(),
                    hintText: "0.00",
                  ),
                ),
                const SizedBox(height: 16),

                // Category Dropdown - COMPLETELY FIXED
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Category*",
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade400),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: categoriesLoading
                            ? const SizedBox(
                          height: 60,
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CircularProgressIndicator(),
                                SizedBox(width: 10),
                                Text("Loading categories..."),
                              ],
                            ),
                          ),
                        )
                            : categories.isEmpty
                            ? const SizedBox(
                          height: 60,
                          child: Center(
                            child: Text("No categories found. Create categories first."),
                          ),
                        )
                            : DropdownButton<String>(
                          isExpanded: true,
                          value: selectedCategoryId,
                          hint: const Text("Select Category"),
                          underline: const SizedBox(),
                          items: [
                            const DropdownMenuItem<String>(
                              value: null,
                              child: Text("Select Category", style: TextStyle(color: Colors.grey)),
                            ),
                            ...categories.map((category) {
                              return DropdownMenuItem<String>(
                                value: category['id'].toString(),
                                child: Text(
                                  "${category['name']} (${category['type']})",
                                  style: TextStyle(
                                    color: category['type'] == 'Income' ? Colors.green : Colors.red,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              );
                            }).toList(),
                          ],
                          onChanged: (String? newValue) {
                            setState(() {
                              selectedCategoryId = newValue;
                            });
                          },
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Date Picker
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.shade400),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: ListTile(
                    title: const Text("Date"),
                    subtitle: Text(DateFormat('MMM dd, yyyy').format(selectedDate)),
                    trailing: const Icon(Icons.calendar_today),
                    onTap: () => _selectDate(context),
                  ),
                ),
                const SizedBox(height: 16),

                // Note
                TextFormField(
                  controller: noteController,
                  decoration: const InputDecoration(
                    labelText: "Note (Optional)",
                    border: OutlineInputBorder(),
                    hintText: "Enter description",
                  ),
                  maxLines: 2,
                ),
                const SizedBox(height: 20),

                // Buttons
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text("Cancel"),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: (isLoading || categories.isEmpty) ? null : _addTransaction,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.bottomNavSelected,
                        ),
                        child: isLoading
                            ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator())
                            : const Text("Add"),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}