import 'package:flutter/material.dart';
import '../api_services/api_services.dart';
import '../app_colors/app_colors.dart';

class StatsTab extends StatefulWidget {
  final String userId;
  const StatsTab({super.key, required this.userId});

  @override
  State<StatsTab> createState() => _StatsTabState();
}

class _StatsTabState extends State<StatsTab> {
  Map<String, dynamic>? overviewData;
  Map<String, dynamic>? reportsData;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      final [overview, reports] = await Future.wait([
        ApiService.getOverview(widget.userId),
        ApiService.getReports(widget.userId),
      ]);

      setState(() {
        overviewData = overview;
        reportsData = reports;
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
      _showSnackBar('Error loading statistics: $e');
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 40),
            const Text(
              "Statistics",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),

            // Summary Cards
            Row(
              children: [
                Expanded(
                  child: _buildSummaryCard(
                    "Total Income",
                    double.tryParse(reportsData?['income']?.toString() ?? '0') ?? 0,
                    Colors.green,
                    Icons.arrow_upward,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildSummaryCard(
                    "Total Expense",
                    double.tryParse(reportsData?['expense']?.toString() ?? '0') ?? 0,
                    Colors.red,
                    Icons.arrow_downward,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _buildSummaryCard(
              "Net Balance",
              (double.tryParse(reportsData?['income']?.toString() ?? '0') ?? 0) -
                  (double.tryParse(reportsData?['expense']?.toString() ?? '0') ?? 0),
              Colors.blue,
              Icons.account_balance_wallet,
            ),
            const SizedBox(height: 30),

            // Category-wise Breakdown
            const Text(
              "Category Breakdown",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            _buildCategoryBreakdown(),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryCard(String title, double amount, Color color, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Icon(icon, color: color),
                Text(
                  "\$${amount.toStringAsFixed(2)}",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                fontSize: 14,
                color: Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryBreakdown() {
    final overview = overviewData?['overview'] ?? [];

    if (overview.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(40),
        child: Column(
          children: [
            Icon(Icons.pie_chart, size: 60, color: Colors.grey[400]),
            const SizedBox(height: 16),
            const Text("No category data available"),
          ],
        ),
      );
    }

    return Column(
      children: overview.map<Widget>((category) {
        final total = double.tryParse(category['total']?.toString() ?? '0') ?? 0;
        final type = category['type'] ?? 'expense';
        final categoryName = category['category'] ?? 'Unknown';

        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: type == 'income'
                  ? Colors.green.withOpacity(0.2)
                  : Colors.red.withOpacity(0.2),
              child: Icon(
                type == 'income' ? Icons.arrow_upward : Icons.arrow_downward,
                color: type == 'income' ? Colors.green : Colors.red,
              ),
            ),
            title: Text(categoryName),
            subtitle: Text(type.toUpperCase()),
            trailing: Text(
              "\$${total.toStringAsFixed(2)}",
              style: TextStyle(
                color: type == 'income' ? Colors.green : Colors.red,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}