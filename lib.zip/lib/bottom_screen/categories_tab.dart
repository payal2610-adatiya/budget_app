import 'package:flutter/material.dart';
import '../api_services/api_services.dart';
import '../app_colors/app_colors.dart';

class CategoriesTab extends StatefulWidget {
  final String userId;
  const CategoriesTab({super.key, required this.userId});

  @override
  State<CategoriesTab> createState() => _CategoriesTabState();
}

class _CategoriesTabState extends State<CategoriesTab> {
  List<Map<String, dynamic>> categories = [];
  final TextEditingController _controller = TextEditingController();
  String? selectedType;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    fetchCategories();
  }

  Future<void> fetchCategories() async {
    setState(() => isLoading = true);
    try {
      final response = await ApiService.viewCategories(widget.userId);
      final data = response;

      if (data['code'] == 200) {
        categories = List<Map<String, dynamic>>.from(data['categories']);
      } else {
        categories = [];
        _showSnackBar(data['message'] ?? 'Failed to fetch categories');
      }
    } catch (e) {
      _showSnackBar('Error: $e');
    }
    setState(() => isLoading = false);
  }

  Future<void> addCategory(String name, String type) async {
    try {
      final response = await ApiService.addCategory(
        userId: widget.userId,
        name: name,
        type: type,
      );
      final data = response;
      if (data['code'] == 200) {
        fetchCategories();
        _showSnackBar("Category added successfully");
      } else {
        _showSnackBar(data['message'] ?? 'Failed to add category');
      }
    } catch (e) {
      _showSnackBar('Error: $e');
    }
  }

  Future<void> updateCategory(String id, String name, String type) async {
    try {
      final response = await ApiService.updateCategory(
        id: id,
        name: name,
        type: type,
      );
      final data = response;
      if (data['status'] == 'success') {
        fetchCategories();
        _showSnackBar("Category updated successfully");
      } else {
        _showSnackBar(data['message'] ?? 'Update failed');
      }
    } catch (e) {
      _showSnackBar('Error: $e');
    }
  }

  Future<void> deleteCategory(String id) async {
    try {
      final response = await ApiService.deleteCategory(id);
      final data = response;
      if (data['code'] == 200) {
        fetchCategories();
        _showSnackBar("Category deleted successfully");
      } else {
        _showSnackBar(data['message'] ?? 'Delete failed');
      }
    } catch (e) {
      _showSnackBar('Error: $e');
    }
  }

  void _showCategoryDialog({String? id, String? currentName, String? currentType}) {
    _controller.text = currentName ?? '';
    selectedType = currentType;

    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        child: Padding(
          padding: const EdgeInsets.all(25),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                id == null ? "New Category" : "Edit Category",
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: _controller,
                decoration: InputDecoration(
                  hintText: "Write category name...",
                  filled: true,
                  fillColor: const Color(0xFFE8FFF3),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(25),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: selectedType,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: const Color(0xFFE8FFF3),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(25),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
                hint: const Text("Select Type"),
                items: const [
                  DropdownMenuItem(value: "Income", child: Text("Income")),
                  DropdownMenuItem(value: "Expense", child: Text("Expense")),
                ],
                onChanged: (value) => setState(() => selectedType = value),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_controller.text.trim().isEmpty || selectedType == null) {
                    _showSnackBar("Enter name and select type!");
                    return;
                  }

                  if (id == null) {
                    addCategory(_controller.text.trim(), selectedType!);
                  } else {
                    updateCategory(id, _controller.text.trim(), selectedType!);
                  }

                  Navigator.pop(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.bottomNavUnselected,
                  minimumSize: const Size(double.infinity, 45),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                ),
                child: const Text("Save", style: TextStyle(color: Colors.white)),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFE8FFF3),
                  minimumSize: const Size(double.infinity, 45),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                ),
                child: const Text("Cancel", style: TextStyle(color: Colors.black87)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pinkAccent,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Row(
                children: const [
                  Expanded(
                    child: Center(
                      child: Text(
                        "Categories",
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: Colors.white),
                      ),
                    ),
                  ),
                  Icon(Icons.notifications_none, color: Colors.white),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(35), topRight: Radius.circular(35)),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 30),
                child: isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 20,
                    crossAxisSpacing: 20,
                    childAspectRatio: 0.9, // Fixed aspect ratio to prevent overflow
                  ),
                  itemCount: categories.length + 1, // +1 for the "Add" button
                  itemBuilder: (context, index) {
                    if (index == categories.length) {
                      // Add button
                      return categoryTile(
                          Icons.add,
                          "More",
                          "",
                          false,
                          onTap: () => _showCategoryDialog()
                      );
                    } else {
                      final cat = categories[index];
                      return categoryTile(
                        cat['type'] == 'Income' ? Icons.arrow_downward : Icons.arrow_upward,
                        cat['name'],
                        cat['type'],
                        false,
                        id: cat['id'].toString(),
                      );
                    }
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget categoryTile(IconData icon, String label, String type, bool selected,
      {VoidCallback? onTap, String? id}) {
    return GestureDetector(
      onTap: onTap ??
              () {
            if (id != null) _showCategoryDialog(id: id, currentName: label, currentType: type);
          },
      child: Container(
        decoration: BoxDecoration(
          color: selected
              ? const Color(0xFF00C896)
              : (type == "Income" ? const Color(0xFFD1F5E0) : const Color(0xFFFDE1E1)),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: selected ? Colors.white : Colors.black87, size: 30),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text(
                label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: selected ? Colors.white : Colors.black87,
                  fontSize: 12, // Smaller font to prevent overflow
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (id != null)
              IconButton(
                icon: const Icon(Icons.delete, color: Colors.redAccent, size: 18),
                onPressed: () => deleteCategory(id),
              ),
          ],
        ),
      ),
    );
  }
}